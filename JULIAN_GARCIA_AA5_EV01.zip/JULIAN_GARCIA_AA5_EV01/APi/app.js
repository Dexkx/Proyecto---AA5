// Iniciamos el servidor
const express = require("express");
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

//llamar e importar rutas en body-parser
app.use(bodyParser.json());
const postRoute = require("./routes/postroute");
app.use("/servicios", postRoute);

app.get("/", (req, res)=>{
    res.send("prueba 1 respuesta del servidor");
});

//Conexión a la DB
const url = "mongodb+srv://prueba:ssfOsTFmiTJlCQnH@cluster0.l0o7qvl.mongodb.net/hola?retryWrites=true&w=majority";
mongoose.connect(url, {useNewUrlParser: true, useUnifiedTopology: true})
    .then(() => console.log("DB Conectada"))
    .catch(e => console.log("DB sin conexion", e))

//Ruta de vista del servidor (localhost:***)
app.listen(10000);
