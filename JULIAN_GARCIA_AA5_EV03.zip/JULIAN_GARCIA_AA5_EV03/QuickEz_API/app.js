const express = require("express");
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

app.use(bodyParser.json());
const rutas = require("./routes/postroutes");
app.use("/quickez", rutas);

const uri = "mongodb+srv://prueba:ssfOsTFmiTJlCQnH@cluster0.l0o7qvl.mongodb.net/QuickEz-a?retryWrites=true&w=majority";
mongoose.connect(uri, {useNewUrlParser: true, useUnifiedTopology: true})
    .then(() => console.log("ON"))
    .catch(e => console.log("OFF", e));

app.listen("20000")
