const model = require("../models/postmodels");
const express = require("express");
const router = express.Router();

router.post("/"), async (req, res) => {

    const insert = new model ({
        num_document : req.body.num_document,
        name_cliente : req.body.name_cliente,
        email : req.body.email
    });

    try{
        const saveInsert = insert.save();
        res.json(saveInsert);
    }catch{
        res.json({message : error});
    }
};

//friltado general
router.get("/"), async (req, res) =>{
    try{
        const dates = await model.find();
        res.json(dates);
    }catch{
        res.json({message : error});
    }
};

//filtrado por _id
router.get("/:Id"), async (req, res) => {
    try{
        const date = await model.findById(req.params.Id);
        res.json(date);
    }catch{
        res.json({message : error});
    }
};

//borrar un dato
router.delete("/:Id"), async (req, res) => {
    try{
        const date = await model.delete(req.params.Id);
        res.json(date);
    }catch{
        res.json({message : error});
    }
};

module.exports = router