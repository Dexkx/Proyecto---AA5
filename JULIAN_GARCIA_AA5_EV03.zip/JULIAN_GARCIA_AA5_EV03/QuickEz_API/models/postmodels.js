const mongoose = require("mongoose");

const Schema = mongoose.Schema ({
    num_document : {type : BigInt},
    name_cliente : {type : String},
    email : {type : String}
});

module.exports = mongoose.model("postroutes", Schema)